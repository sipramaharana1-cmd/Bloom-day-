package com.bloomday.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Sky = Color(0xFFDDF3FF)
private val Pink = Color(0xFFFFDDE8)
private val Cream = Color(0xFFFFF8F0)
private val Green = Color(0xFFDFF4E4)
private val Red = Color(0xFFFFE1E1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BloomDayApp() }
    }
}

data class Task(val title: String, val time: String, val icon: String, var done: Boolean = false)

@Composable
fun BloomDayApp() {
    var selected by remember { mutableIntStateOf(0) }
    var tasks by remember { mutableStateOf(listOf(
        Task("Study", "7:00 PM", "📚"), Task("Drink Water", "8:00 PM", "💧"),
        Task("Prayer", "8:30 PM", "🙏"), Task("Spoken Practice", "9:00 PM", "🗣️"),
        Task("Learn Something New", "9:30 PM", "🌱"), Task("Good-Moral Reminder", "10:00 PM", "🤍")
    )) }
    var showAdd by remember { mutableStateOf(false) }
    val completed = tasks.count { it.done }
    val progress = if (tasks.isEmpty()) 0f else completed.toFloat() / tasks.size

    Scaffold(containerColor = Cream, bottomBar = {
        NavigationBar(containerColor = Color.White) {
            listOf("Today" to "🏠", "Study" to "📚", "Games" to "🎮", "Diary" to "📔", "Profile" to "👤").forEachIndexed { i, item ->
                NavigationBarItem(selected = selected == i, onClick = { selected = i }, icon = { Text(item.second) }, label = { Text(item.first) })
            }
        }
    }, floatingActionButton = {
        if (selected == 0) FloatingActionButton(onClick = { showAdd = true }, containerColor = Pink) { Text("+", fontSize = 28.sp) }
    }) { padding ->
        when (selected) {
            0 -> TodayScreen(tasks, progress, completed, onToggle = { index -> tasks = tasks.mapIndexed { i, t -> if (i == index) t.copy(done = !t.done) else t } }, Modifier.padding(padding))
            1 -> StudyScreen(Modifier.padding(padding))
            2 -> GamesScreen(Modifier.padding(padding))
            3 -> DiaryScreen(Modifier.padding(padding))
            else -> ProfileScreen(Modifier.padding(padding))
        }
    }
    if (showAdd) AddTaskDialog(onDismiss = { showAdd = false }) { title, time -> tasks = tasks + Task(title, time, "📝"); showAdd = false }
}

@Composable fun TodayScreen(tasks: List<Task>, progress: Float, completed: Int, onToggle: (Int) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 90.dp)) {
        item { Text("🌤️ Good Morning!", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        item { Text("Small progress every day becomes something beautiful. 🌷", color = Color.DarkGray) }
        item { Card(colors = CardDefaults.cardColors(containerColor = Sky), shape = RoundedCornerShape(24.dp)) { Column(Modifier.padding(18.dp)) { Text("🔥 Current Streak", fontWeight = FontWeight.Bold); Text("7 Days", fontSize = 26.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = Color(0xFF6BB7D6), trackColor = Color.White); Text("$completed / ${tasks.size} tasks completed today", modifier = Modifier.padding(top = 8.dp)) } } }
        item { Text("Today's Tasks", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp)) }
        items(tasks) { task -> val index = tasks.indexOf(task); TaskCard(task, { onToggle(index) }) }
        item { Card(colors = CardDefaults.cardColors(containerColor = Pink), shape = RoundedCornerShape(20.dp)) { Text("🌿 Today's Moral Reminder\nBe kind, be honest, be patient, and respect yourself.", Modifier.padding(16.dp), fontWeight = FontWeight.Medium) } }
    }
}

@Composable fun TaskCard(task: Task, onToggle: () -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = if (task.done) Green else Red), shape = RoundedCornerShape(18.dp)) { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(task.icon, fontSize = 26.sp); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(task.title, fontWeight = FontWeight.SemiBold, fontSize = 17.sp); Text(task.time, color = Color.DarkGray) }; Button(onClick = onToggle) { Text(if (task.done) "Done ✓" else "Complete") } } } }

@Composable fun StudyScreen(modifier: Modifier) { SimplePage("📚 Study", "Choose a subject", listOf("➗ Mathematics", "🇬🇧 English", "📝 Odia", "🌎 GK & Current Affairs", "🏛️ History", "🗺️ Geography", "➕ Add Subject"), modifier) }
@Composable fun GamesScreen(modifier: Modifier) { SimplePage("🎮 Maths Games", "Practice and improve", listOf("Multiplication Tables", "Squares", "Square Roots", "Mental Maths", "Daily Challenge", "🏆 Streak & Points"), modifier) }
@Composable fun DiaryScreen(modifier: Modifier) { SimplePage("📔 My Diary", "Write about your day", listOf("Today's Entry", "What did I accomplish?", "What did I learn?", "How am I feeling?"), modifier) }
@Composable fun ProfileScreen(modifier: Modifier) { SimplePage("👤 Profile", "Bloom Day", listOf("🔔 Notifications", "💧 Water Goal", "⏰ Task Times", "🔥 Streak History", "➕ Add More Options"), modifier) }

@Composable fun SimplePage(title: String, subtitle: String, items: List<String>, modifier: Modifier) { LazyColumn(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { item { Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Color.Gray) }; items(items) { Card(colors = CardDefaults.cardColors(containerColor = Sky), shape = RoundedCornerShape(18.dp)) { Text(it, Modifier.fillMaxWidth().padding(18.dp), fontSize = 17.sp, fontWeight = FontWeight.Medium) } } } }

@Composable fun AddTaskDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) { var title by remember { mutableStateOf("") }; var time by remember { mutableStateOf("") }; AlertDialog(onDismissRequest = onDismiss, title = { Text("Add Task") }, text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { OutlinedTextField(title, { title = it }, label = { Text("Task") }); OutlinedTextField(time, { time = it }, label = { Text("Time") }) } }, confirmButton = { TextButton(onClick = { if (title.isNotBlank()) onAdd(title, time.ifBlank { "Any time" }) }) { Text("Add") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }) }
